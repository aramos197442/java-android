package br.uninga.aula01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ListaClientesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_clientes);
    }
}